﻿namespace Nop.Plugin.NopStation.BlogNews.Domains
{
    public enum EntityType
    {
        Blog = 10,
        News = 20
    }
}
