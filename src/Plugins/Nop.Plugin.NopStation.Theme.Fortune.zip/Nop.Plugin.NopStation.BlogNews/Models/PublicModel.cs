﻿using Nop.Web.Framework.Models;
using System.Collections.Generic;

namespace Nop.Plugin.NopStation.BlogNews.Models
{
    public class PublicModel
    {
        public PublicModel()
        {
            BlogPosts = new List<BlogPostModel>();
            NewsItems = new List<NewsItemModel>();
        }

        public IList<BlogPostModel> BlogPosts { get; set; }
        public IList<NewsItemModel> NewsItems { get; set; }

        public class BlogPostModel : BaseNopEntityModel
        {
            public string BodyOverview { get; set; }
            public string CreatedOnUtcStr { get; set; }
            public int TotalComments { get; set; }
            public string PictureUrl { get; set; }
            public string AltAttribute { get; set; }
            public string TitleAttribute { get; set; }
            public string SeName { get; set; }
            public string Title { get; set; }
            public bool AllowComments { get; set; }
        }

        public class NewsItemModel : BaseNopEntityModel
        {
            public string Title { get; set; }
            public string CreatedOnUtcStr { get; set; }
            public string PictureUrl { get; set; }
            public string AltAttribute { get; set; }
            public string TitleAttribute { get; set; }
            public string SeName { get; set; }
            public string ShortDescription { get; set; }
            public bool AllowComments { get; set; }
            public int TotalComments { get; set; }
        }
    }
}
