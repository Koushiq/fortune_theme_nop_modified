﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.ProductTabs.Helpers
{
    public class ProductTabWidgetZoneModel
    {
        public string Name { get; set; }

        public int Value { get; set; }
    }
}
