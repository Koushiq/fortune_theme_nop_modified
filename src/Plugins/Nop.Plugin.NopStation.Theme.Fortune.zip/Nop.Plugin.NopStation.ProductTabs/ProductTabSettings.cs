﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.ProductTabs
{
    public class ProductTabSettings : ISettings
    {
        public bool EnableProductTab { get; set; }
    }
}
