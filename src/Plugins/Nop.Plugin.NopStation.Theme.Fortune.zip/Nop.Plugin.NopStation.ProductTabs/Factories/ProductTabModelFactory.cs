﻿using System;
using System.Collections.Generic;
using System.Linq;
using Nop.Core.Caching;
using Nop.Core.Domain.Media;
using Nop.Services.Catalog;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Services.Seo;
using Nop.Web.Models.Media;
using Nop.Web.Factories;
using Nop.Core;
using Nop.Services.Orders;
using Nop.Services.Stores;
using Nop.Services.Security;
using Nop.Plugin.NopStation.ProductTabs.Services;
using Nop.Plugin.NopStation.ProductTabs.Domains;
using Nop.Plugin.NopStation.ProductTabs.Models;

namespace Nop.Plugin.NopStation.ProductTabs.Factories
{
    public class ProductTabModelFactory : IProductTabModelFactory
    {
        #region Fields

        private readonly ICategoryService _categoryService;
        private readonly IPictureService _pictureService;
        private readonly IProductService _productService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly ILocalizationService _localizationService;
        private readonly MediaSettings _mediaSettings;
        private readonly IProductModelFactory _productModelFactory;
        private readonly IManufacturerService _manufacturerService;
        private readonly IRecentlyViewedProductsService _recentlyViewedProductsService;
        private readonly IStoreContext _storeContext;
        private readonly IOrderReportService _orderReportService;
        private readonly IStoreMappingService _storeMappingService;
        private readonly IAclService _aclService;
        private readonly IProductTabService _productTabService;
        private readonly IWorkContext _workContext;

        #endregion

        #region Ctor

        public ProductTabModelFactory(ICategoryService categoryService,
            IPictureService pictureService,
            IProductService productService,
            IUrlRecordService urlRecordService,
            ILocalizationService localizationService,
            MediaSettings mediaSettings,
            IProductModelFactory productModelFactory,
            IManufacturerService manufacturerService,
            IRecentlyViewedProductsService recentlyViewedProductsService,
            IStoreContext storeContext,
            IOrderReportService orderReportService,
            IStoreMappingService storeMappingService,
            IAclService aclService,
            IProductTabService productTabService,
            IWorkContext workContext)
        {
            _categoryService = categoryService;
            _pictureService = pictureService;
            _productService = productService;
            _urlRecordService = urlRecordService;
            _localizationService = localizationService;
            _mediaSettings = mediaSettings;
            _productModelFactory = productModelFactory;
            _manufacturerService = manufacturerService;
            _recentlyViewedProductsService = recentlyViewedProductsService;
            _storeContext = storeContext;
            _orderReportService = orderReportService;
            _storeMappingService = storeMappingService;
            _aclService = aclService;
            _productTabService = productTabService;
            _workContext = workContext;
        }

        #endregion

        #region Utlities 

        protected PictureModel PreparePictureModel(ProductTab productTab)
        {
            return new PictureModel()
            {
                ImageUrl = _pictureService.GetPictureUrl(productTab.PictureId),
                AlternateText = productTab.PictureAlt,
                Title = productTab.PictureTitle
            };
        }
        
        #endregion

        #region Methods

        public IList<ProductTabModel> PrepareProductTabListModel(List<ProductTab> productTabs)
        {
            if (productTabs == null)
                throw new ArgumentNullException(nameof(productTabs));

            var model = new List<ProductTabModel>();
            foreach (var productTab in productTabs)
            {
                model.Add(PrepareProductTabModel(productTab));
            }
            return model;
        }

        public ProductTabModel PrepareProductTabModel(ProductTab productTab)
        {
            if (productTab == null)
                throw new ArgumentNullException(nameof(productTab));

            var model = new ProductTabModel();

            model.Id = productTab.Id;
            if (productTab.DisplayTitle)
            {
                model.DisplayTitle = productTab.DisplayTitle;
                model.Title = _localizationService.GetLocalized(productTab, x => x.TabTitle);
            }
            model.AutoPlay = productTab.AutoPlay;
            model.RTL = _workContext.WorkingLanguage.Rtl;
            model.CustomCssClass = productTab.CustomCssClass;
            model.AutoPlayHoverPause = productTab.AutoPlayHoverPause;
            model.AutoPlayTimeout = productTab.AutoPlayTimeout;
            model.Center = productTab.Center;
            model.LazyLoad = productTab.LazyLoad;
            model.LazyLoadEager = productTab.LazyLoadEager;
            model.Loop = productTab.Loop;
            model.Margin = productTab.Margin;
            model.Nav = productTab.Nav;
            model.StartPosition = productTab.StartPosition;
            model.CustomUrl = productTab.CustomUrl;

            model.Picture = PreparePictureModel(productTab);

            var productTabItems = _productTabService.GetProductTabItemsByProductTabId(productTab.Id);

            foreach (var item in productTabItems)
            {
                model.Items.Add(PrepareProductTabItemModel(item));
            }
            
            return model;
        }

        private ProductTabModel.ProductTabItem PrepareProductTabItemModel(ProductTabItem item)
        {
            var model = new ProductTabModel.ProductTabItem()
            {
                Name = _localizationService.GetLocalized(item, x => x.Name),
                Id = item.Id
            };

            var productIds = _productTabService.GetProductTabItemProductsByProductTabItemId(item.Id).Select(x=>x.ProductId).ToArray();// item.ProductTabItemProducts.Select(x => x.ProductId).ToArray();
            var sp = _productService.GetProductsByIds(productIds).Where(p => p.Published).ToList();
            sp = sp.Where(p => _aclService.Authorize(p) && _storeMappingService.Authorize(p)).ToList();
            sp = sp.Where(p => _productService.ProductIsAvailable(p)).ToList();
            model.Products = _productModelFactory.PrepareProductOverviewModels(sp).ToList();

            return model;
        }

        #endregion
    }
}
