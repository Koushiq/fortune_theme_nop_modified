﻿using System.Collections.Generic;
using Nop.Core;
using Nop.Core.Domain.Localization;

namespace Nop.Plugin.NopStation.ProductTabs.Domains
{
    public class ProductTabItem : BaseEntity, ILocalizedEntity
    {
        private ICollection<ProductTabItemProduct> _productTabItemProducts;

        public string Name { get; set; }

        public int DisplayOrder { get; set; }

        public int ProductTabId { get; set; }
        

        public virtual ProductTab ProductTab { get; set; }
        
        public virtual ICollection<ProductTabItemProduct> ProductTabItemProducts
        {
            get => _productTabItemProducts ?? (_productTabItemProducts = new List<ProductTabItemProduct>());
            set => _productTabItemProducts = value;
        }
    }
}
