﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.NopStation.Core.Services;
using Nop.Plugin.NopStation.ProductTabs.Factories;
using Nop.Plugin.NopStation.ProductTabs.Helpers;
using Nop.Plugin.NopStation.ProductTabs.Services;
using Nop.Web.Framework.Components;
using System.Collections.Generic;
using System.Linq;

namespace Nop.Plugin.NopStation.ProductTabs.Components
{
    public class ProductTabViewComponent : NopViewComponent
    {
        private readonly IStoreContext _storeContext;
        private readonly INopStationLicenseService _licenseService;
        private readonly ProductTabSettings _productTabSettings;
        private readonly IProductTabModelFactory _productTabModelFactory;
        private readonly IProductTabService _productTabService;

        public ProductTabViewComponent(IStoreContext storeContext,
            INopStationLicenseService licenseService,
            IProductTabModelFactory productTabModelFactory,
            IProductTabService productTabService,
            ProductTabSettings productTabSettings)
        {
            _licenseService = licenseService;
            _productTabSettings = productTabSettings;
            _productTabService = productTabService;
            _storeContext = storeContext;
            _productTabModelFactory = productTabModelFactory;
        }

        public IViewComponentResult Invoke(string widgetZone, object additionalData)
        {
            if (!_licenseService.IsLicensed())
                return Content("");

            if (!ProductTabHelper.TryGetWidgetZoneId(widgetZone, out int widgetZoneId))
                return Content("");

            if (!_productTabSettings.EnableProductTab)
                return Content("");

            var productTabs = _productTabService.GetAllProductTabs(new List<int> { widgetZoneId },
                true, _storeContext.CurrentStore.Id, true).ToList();
            var model = _productTabModelFactory.PrepareProductTabListModel(productTabs);

            return View(model);
        }
    }
}
