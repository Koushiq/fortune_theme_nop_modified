﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.NopStation.ProductTabs.Areas.Admin.Models
{
    public class ProductTabListModel : BasePagedListModel<ProductTabModel>
    {
    }
}