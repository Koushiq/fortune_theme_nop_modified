﻿using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.NopStation.Core.Infrastructure;
using Nop.Plugin.NopStation.Theme.Fortune.Areas.Admin.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Messages;
using Nop.Services.Security;
using Nop.Web.Areas.Admin.Controllers;
using Nop.Web.Areas.Admin.Infrastructure.Mapper.Extensions;

namespace Nop.Plugin.NopStation.Theme.Fortune.Areas.Admin.Controllers
{
    [NopStationLicense]
    public class FortuneController : BaseAdminController
    {
        #region Fields

        private readonly IPermissionService _permissionService;
        private readonly ISettingService _settingService;
        private readonly IStoreContext _storeContext;
        private readonly ILocalizationService _localizationService;
        private readonly INotificationService _notificationService;

        #endregion

        #region Ctor

        public FortuneController(IPermissionService permissionService,
            ISettingService settingService,
            IStoreContext storeContext,
            ILocalizationService localizationService,
            INotificationService notificationService)
        {
            _permissionService = permissionService;
            _settingService = settingService;
            _storeContext = storeContext;
            _localizationService = localizationService;
            _notificationService = notificationService;
        }

        #endregion

        #region Methods

        public IActionResult Configure()
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageBlog))
                return AccessDeniedView();

            var storeId = _storeContext.ActiveStoreScopeConfiguration;
            var fortuneSettings = _settingService.LoadSetting<FortuneSettings>(storeId);
            var model = fortuneSettings.ToSettingsModel<ConfigurationModel>();

            model.ActiveStoreScopeConfiguration = storeId;

            if (storeId <= 0)
                return View(model);

            model.CustomCss_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.CustomCss, storeId);
            model.EnableImageLazyLoad_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.EnableImageLazyLoad, storeId);
            model.FooterEmail_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.FooterEmail, storeId);
            model.FooterLogoPictureId_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.FooterLogoPictureId, storeId);
            model.LazyLoadPictureId_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.LazyLoadPictureId, storeId);
            model.ShowLogoAtPageFooter_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.ShowLogoAtPageFooter, storeId);
            model.ShowSupportedCardsPictureAtPageFooter_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.ShowSupportedCardsPictureAtPageFooter, storeId);
            model.SupportedCardsPictureId_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.SupportedCardsPictureId, storeId);
            model.FooterTopDescription_OverrideForStore = _settingService.SettingExists(fortuneSettings, x => x.FooterTopDescription, storeId);
           
            return View(model);
        }

        [HttpPost]
        public IActionResult Configure(ConfigurationModel model)
        {
            if (!_permissionService.Authorize(StandardPermissionProvider.ManageBlog))
                return AccessDeniedView();

            var storeScope = _storeContext.ActiveStoreScopeConfiguration;
            var fortuneSettings = _settingService.LoadSetting<FortuneSettings>(storeScope);
            fortuneSettings = model.ToSettings(fortuneSettings);

            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.CustomCss, model.CustomCss_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.EnableImageLazyLoad, model.EnableImageLazyLoad_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.FooterEmail, model.FooterEmail_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.FooterLogoPictureId, model.FooterLogoPictureId_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.LazyLoadPictureId, model.LazyLoadPictureId_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.ShowLogoAtPageFooter, model.ShowLogoAtPageFooter_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.ShowSupportedCardsPictureAtPageFooter, model.ShowSupportedCardsPictureAtPageFooter_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.SupportedCardsPictureId, model.SupportedCardsPictureId_OverrideForStore, storeScope, false);
            _settingService.SaveSettingOverridablePerStore(fortuneSettings, x => x.FooterTopDescription, model.FooterTopDescription_OverrideForStore, storeScope, false);

            _settingService.ClearCache();

            _notificationService.SuccessNotification(_localizationService.GetResource("Admin.NopStation.Theme.Fortune.Configuration.Updated"));

            return RedirectToAction("Configure");
        }

        #endregion
    }
}
