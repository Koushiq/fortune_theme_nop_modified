﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.Theme.Fortune
{
    public class FortuneSettings : ISettings
    {
        public bool EnableImageLazyLoad { get; set; }

        public int LazyLoadPictureId { get; set; }

        public bool ShowSupportedCardsPictureAtPageFooter { get; set; }

        public int SupportedCardsPictureId { get; set; }

        public bool ShowLogoAtPageFooter { get; set; }

        public int FooterLogoPictureId { get; set; }

        public string FooterEmail { get; set; }

        public string FooterTopDescription { get; set; }

        public string CustomCss { get; set; }
    }
}
