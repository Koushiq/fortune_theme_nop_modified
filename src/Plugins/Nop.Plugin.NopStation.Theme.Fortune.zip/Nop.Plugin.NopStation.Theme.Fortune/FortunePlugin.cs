﻿using System.Collections.Generic;
using Nop.Core;
using Nop.Plugin.NopStation.Core;
using Nop.Plugin.NopStation.Core.Helpers;
using Nop.Plugin.NopStation.Core.Services;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Plugins;
using Nop.Services.Security;
using Nop.Web.Framework.Menu;
using Nop.Web.Framework.Infrastructure;
using Nop.Services.Media;
using Nop.Core.Infrastructure;
using System.Web;

namespace Nop.Plugin.NopStation.Theme.Fortune
{
    public class FortunePlugin : BasePlugin, IWidgetPlugin, IAdminMenuPlugin, INopStationPlugin
    {
        #region Fields

        public bool HideInWidgetList => false;

        private readonly ISettingService _settingService;
        private readonly IWebHelper _webHelper;
        private readonly IPictureService _pictureService;
        private readonly INopFileProvider _fileProvider;
        private readonly ILocalizationService _localizationService;
        private readonly IPermissionService _permissionService;
        private readonly INopStationCoreService _nopStationCoreService;

        #endregion

        #region Ctor

        public FortunePlugin(ISettingService settingService, 
            IWebHelper webHelper,
            INopFileProvider nopFileProvider,
            IPictureService pictureService,
            ILocalizationService localizationService,
            IPermissionService permissionService,
            INopStationCoreService nopStationCoreService)
        {
            _settingService = settingService;
            _webHelper = webHelper;
            _fileProvider = nopFileProvider;
            _pictureService = pictureService;
            _localizationService = localizationService;
            _permissionService = permissionService;
            _nopStationCoreService = nopStationCoreService;
        }

        #endregion

        #region Utilities

        private void CreateSampleData()
        {
            var sampleImagesPath = _fileProvider.MapPath("~/Plugins/NopStation.Theme.Fortune/Content/sample/");

            var settings = new FortuneSettings()
            {
                EnableImageLazyLoad = true,
                FooterEmail = "sales@nop-station.com",
                LazyLoadPictureId = _pictureService.InsertPicture(_fileProvider.ReadAllBytes(_fileProvider.Combine(sampleImagesPath, "lazy-load.png")), MimeTypes.ImagePng, "lazy-load").Id,
                SupportedCardsPictureId = _pictureService.InsertPicture(_fileProvider.ReadAllBytes(_fileProvider.Combine(sampleImagesPath, "footer-card-icons.png")), MimeTypes.ImagePng, "footer-cards").Id,
                FooterLogoPictureId = _pictureService.InsertPicture(_fileProvider.ReadAllBytes(_fileProvider.Combine(sampleImagesPath, "footer-logo-white.png")), MimeTypes.ImagePng, "footer-logo").Id,
                ShowLogoAtPageFooter = true,
                ShowSupportedCardsPictureAtPageFooter = true
            };
            _settingService.SaveSetting(settings);
        }

        #endregion

        #region Methods

        public IList<string> GetWidgetZones()
        {
            return new List<string> { PublicWidgetZones.HeadHtmlTag };
        }

        public override string GetConfigurationPageUrl()
        {
            return _webHelper.GetStoreLocation() + "Admin/Fortune/Configure";
        }

        public override void Install()
        {
            CreateSampleData();
            this.NopStationPluginInstall(new FortunePermissionProvider());
            base.Install();
        }

        public override void Uninstall()
        {
            this.NopStationPluginUninstall(new FortunePermissionProvider());
            base.Uninstall();
        }

        public void ManageSiteMap(SiteMapNode rootNode)
        {
            if (_permissionService.Authorize(FortunePermissionProvider.ManageFortune))
            {
                var menuItem = new SiteMapNode()
                {
                    Title = _localizationService.GetResource("Admin.NopStation.Theme.Fortune.Menu.Fortune"),
                    Visible = true,
                    IconClass = "fa-circle-o",
                };

                var configItem = new SiteMapNode()
                {
                    Title = _localizationService.GetResource("Admin.NopStation.Theme.Fortune.Menu.Configuration"),
                    Url = "/Admin/Fortune/Configure",
                    Visible = true,
                    IconClass = "fa-genderless",
                    SystemName = "Fortune.Configuration"
                };
                menuItem.ChildNodes.Add(configItem);

                var documentation = new SiteMapNode()
                {
                    Title = _localizationService.GetResource("Admin.NopStation.Common.Menu.Documentation"),
                    Url = "https://www.nop-station.com/fortune-theme-documentation?utm_source=admin-panel",
                    Visible = true,
                    IconClass = "fa-genderless",
                    OpenUrlInNewTab = true
                };
                menuItem.ChildNodes.Add(documentation);

                _nopStationCoreService.ManageSiteMap(rootNode, menuItem, NopStationMenuType.Theme);
            }
        }

        public string GetWidgetViewComponentName(string widgetZone)
        {
            return "Fortune";
        }

        public List<KeyValuePair<string, string>> PluginResouces()
        {
            var list = new List<KeyValuePair<string, string>>();

            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Menu.Fortune", "Fortune"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Menu.Configuration", "Configuration"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.EnableImageLazyLoad", "Enable image lazy-load"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.EnableImageLazyLoad.Hint", "Check to enable lazy-load for product box image."));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.LazyLoadPictureId", "Lazy-load picture"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.LazyLoadPictureId.Hint", "This picture will be displayed initially in product box. Uploaded picture size should not be more than 4-5 KB."));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.FooterTopDescription", "Footer top description"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.FooterTopDescription.Hint", "Enter description which will be displayed at the top of the footer part."));

            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.ShowSupportedCardsPictureAtPageFooter", "Show supported cards picture at page footer"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.ShowSupportedCardsPictureAtPageFooter.Hint", "Determines whether supported cards picture will be displayed at page footer or not."));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.SupportedCardsPictureId", "Supported cards picture"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.SupportedCardsPictureId.Hint", "The single picture of supported cards (expected image height 30px)."));

            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.ShowLogoAtPageFooter", "Show logo at page footer"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.ShowLogoAtPageFooter.Hint", "Determines whether logo will be displayed at page footer or not."));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.FooterLogoPictureId", "Footer logo"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.FooterLogoPictureId.Hint", "This footer logo for this store (expected image height 40px)."));

            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.CustomCss", "Custom Css"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.CustomCss.Hint", "Write custom CSS for your site. It will be rendered in head section of html page."));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.FooterEmail", "Footer email"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Fields.FooterEmail.Hint", "Specify email which which will be displayed at page footer."));

            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration", "Fortune settings"));
            list.Add(new KeyValuePair<string, string>("Admin.NopStation.Theme.Fortune.Configuration.Updated", "Fortune configuration updated successfully."));

            list.Add(new KeyValuePair<string, string>("NopStation.Theme.Fortune.ProductDetailsPage.Overview", "Overview"));
            list.Add(new KeyValuePair<string, string>("NopStation.Theme.Fortune.ProductDetailsPage.Specifications", "Specifications"));
            list.Add(new KeyValuePair<string, string>("NopStation.Theme.Fortune.ProductDetailsPage.ProductTags", "Product Tags"));
            list.Add(new KeyValuePair<string, string>("NopStation.Theme.Fortune.ShoppingCart.Info", "Info"));

            return list;
        }

        #endregion
    }
}