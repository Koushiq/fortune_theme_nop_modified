﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.NopStation.Theme.Fortune.Models
{
    public class PublicModel
    {
        public string CustomCss { get; set; }

        public bool EnableImageLazyLoad { get; set; }
    }
}
