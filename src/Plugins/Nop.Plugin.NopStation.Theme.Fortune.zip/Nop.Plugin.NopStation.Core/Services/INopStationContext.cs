﻿namespace Nop.Plugin.NopStation.Core.Services
{
    public interface INopStationContext
    {
        bool MobileDevice { get; }
    }
}