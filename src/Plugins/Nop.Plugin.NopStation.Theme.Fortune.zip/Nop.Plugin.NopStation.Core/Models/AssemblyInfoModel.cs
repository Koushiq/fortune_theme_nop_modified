﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.NopStation.Core.Models
{
    public class AssemblyInfoModel
    {
        public string FileName { get; set; }

        public string Version { get; set; }
    }
}
