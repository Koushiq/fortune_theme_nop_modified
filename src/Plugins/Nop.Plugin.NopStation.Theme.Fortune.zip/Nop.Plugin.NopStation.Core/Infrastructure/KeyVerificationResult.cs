﻿namespace Nop.Plugin.NopStation.Core.Infrastructure
{
    public enum KeyVerificationResult
    {
        InvalidProductKey,
        InvalidForDomain,
        InvalidForNOPVersion,
        Valid
    }
}
