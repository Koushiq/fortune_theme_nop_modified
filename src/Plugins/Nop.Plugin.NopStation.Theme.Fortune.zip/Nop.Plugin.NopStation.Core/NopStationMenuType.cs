﻿namespace Nop.Plugin.NopStation.Core
{
    public enum NopStationMenuType
    {
        Theme,
        Plugin,
        Root,
        Core
    }
}
