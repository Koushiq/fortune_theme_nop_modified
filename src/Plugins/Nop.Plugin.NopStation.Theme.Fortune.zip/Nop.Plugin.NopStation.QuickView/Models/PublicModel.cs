﻿namespace Nop.Plugin.NopStation.QuickView.Models
{
    public partial class PublicModel
    {
        public int ProductId { get; set; }

        public bool PictureZoomEnabled { get; set; }
    }
}
