﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nop.Plugin.NopStation.QuickView.Models
{
    public class PublicFooterModel
    {
        public bool PictureZoomEnabled { get; set; }
    }
}
