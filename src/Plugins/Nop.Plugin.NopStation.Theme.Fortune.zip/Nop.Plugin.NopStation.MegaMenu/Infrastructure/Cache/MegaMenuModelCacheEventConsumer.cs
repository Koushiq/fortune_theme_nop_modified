﻿using Nop.Core.Caching;
using Nop.Core.Domain.Catalog;
using Nop.Core.Domain.Topics;
using Nop.Core.Events;
using Nop.Services.Events;

namespace Nop.Plugin.NopStation.MegaMenu.Infrastructure.Cache
{
    public class MegaMenuModelCacheEventConsumer:
        IConsumer<EntityInsertedEvent<Manufacturer>>,
        IConsumer<EntityUpdatedEvent<Manufacturer>>,
        IConsumer<EntityDeletedEvent<Manufacturer>>,
        IConsumer<EntityInsertedEvent<Category>>,
        IConsumer<EntityUpdatedEvent<Category>>,
        IConsumer<EntityDeletedEvent<Category>>,
        IConsumer<EntityInsertedEvent<Topic>>,
        IConsumer<EntityUpdatedEvent<Topic>>,
        IConsumer<EntityDeletedEvent<Topic>>
    {
        public static string Megamenu_topics_model_key = "Nopstation.megamenu.topic-{0}-{1}-{2}";
        public static string Megamenu_topics_patern_key = "Nopstation.megamenu.topic";
        public static string Megamenu_categories_model_key = "Nopstation.megamenu.categories-{0}-{1}-{2}";
        public static string Megamenu_categories_patern_key = "Nopstation.megamenu.categories";
        public static string Megamenu_manufacturers_model_key = "Nopstation.megamenu.manufacturers-{0}-{1}-{2}";
        public static string Megamenu_manufacturers_patern_key = "Nopstation.megamenu.manufacturers";
        public static string Megamenu_model_key = "Nopstation.megamenu.all-{0}-{1}-{2}";
        public static string Megamenu_patern_key = "Nopstation.megamenu.";

        private readonly IStaticCacheManager _cacheManager;

        public MegaMenuModelCacheEventConsumer(IStaticCacheManager cacheManager)
        {
            _cacheManager = cacheManager;
        }

        public void HandleEvent(EntityInsertedEvent<Manufacturer> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_manufacturers_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<Manufacturer> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_manufacturers_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityDeletedEvent<Manufacturer> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_manufacturers_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityInsertedEvent<Category> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_categories_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<Category> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_categories_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityDeletedEvent<Category> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_categories_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }
        public void HandleEvent(EntityInsertedEvent<Topic> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_topics_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<Topic> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_topics_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }

        public void HandleEvent(EntityDeletedEvent<Topic> eventMessage)
        {
            _cacheManager.RemoveByPrefix(Megamenu_topics_patern_key);
            _cacheManager.RemoveByPrefix(Megamenu_patern_key);
        }
    }
}
