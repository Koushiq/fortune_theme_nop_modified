﻿using Nop.Plugin.NopStation.MegaMenu.Models;

namespace Nop.Plugin.NopStation.MegaMenu.Factories
{
    public interface IMegaMenuModelFactory
    {
        MegaMenuModel PrepareMegaMenuModel();
    }
}