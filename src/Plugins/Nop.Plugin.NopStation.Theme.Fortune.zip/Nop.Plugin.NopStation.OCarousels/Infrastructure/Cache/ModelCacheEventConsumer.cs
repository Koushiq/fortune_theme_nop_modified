﻿using Nop.Core.Caching;
using Nop.Core.Domain.Catalog;
using Nop.Core.Events;
using Nop.Services.Events;
using Nop.Plugin.NopStation.OCarousels.Domains;

namespace Nop.Plugin.NopStation.OCarousels.Infrastructure.Cache
{
    public partial class ModelCacheEventConsumer :
        IConsumer<EntityInsertedEvent<Manufacturer>>,
        IConsumer<EntityUpdatedEvent<Manufacturer>>,
        IConsumer<EntityDeletedEvent<Manufacturer>>,
        IConsumer<EntityInsertedEvent<Category>>,
        IConsumer<EntityUpdatedEvent<Category>>,
        IConsumer<EntityDeletedEvent<Category>>,
        IConsumer<EntityInsertedEvent<OCarousel>>,
        IConsumer<EntityUpdatedEvent<OCarousel>>,
        IConsumer<EntityDeletedEvent<OCarousel>>,
        IConsumer<EntityInsertedEvent<OCarouselItem>>,
        IConsumer<EntityUpdatedEvent<OCarouselItem>>,
        IConsumer<EntityDeletedEvent<OCarouselItem>>
    {
        public static string OCarousel_category_model_key = "Nopstation.ocarousel.items.category.{0}-{1}-{2}-{3}";
        public static string OCarousel_category_pattern_key = "Nopstation.ocarousel.items.category.";

        public static string OCarousel_manufacturer_model_key = "Nopstation.ocarousel.items.manufacturer.{0}-{1}-{2}-{3}";
        public static string OCarousel_manufacturer_pattern_key = "Nopstation.ocarousel.items.manufacturer.";

        public static string OCarousel_customroductids_model_key = "Nopstation.ocarousel.items.customroductids.{0}";
        public static string OCarousel_customproductids_pattern_key = "Nopstation.ocarousel.items.customroductids.";

        private readonly IStaticCacheManager _cacheManager;

        public ModelCacheEventConsumer(IStaticCacheManager cacheManager)
        {
            _cacheManager = cacheManager;
        }

        public void HandleEvent(EntityInsertedEvent<Manufacturer> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_manufacturer_pattern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<Manufacturer> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_manufacturer_pattern_key);
        }

        public void HandleEvent(EntityDeletedEvent<Manufacturer> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_manufacturer_pattern_key);
        }

        public void HandleEvent(EntityInsertedEvent<Category> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_category_pattern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<Category> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_category_pattern_key);
        }

        public void HandleEvent(EntityDeletedEvent<Category> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_category_pattern_key);
        }

        public void HandleEvent(EntityInsertedEvent<OCarousel> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_customproductids_pattern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<OCarousel> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_customproductids_pattern_key);
        }

        public void HandleEvent(EntityDeletedEvent<OCarousel> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_customproductids_pattern_key);
        }

        public void HandleEvent(EntityInsertedEvent<OCarouselItem> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_customproductids_pattern_key);
        }

        public void HandleEvent(EntityUpdatedEvent<OCarouselItem> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_customproductids_pattern_key);
        }

        public void HandleEvent(EntityDeletedEvent<OCarouselItem> eventMessage)
        {
            _cacheManager.RemoveByPrefix(OCarousel_customproductids_pattern_key);
        }
    }
}
