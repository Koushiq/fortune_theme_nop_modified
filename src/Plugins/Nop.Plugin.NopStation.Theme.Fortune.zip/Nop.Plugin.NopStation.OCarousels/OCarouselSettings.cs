﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.OCarousels
{
    public class OCarouselSettings : ISettings
    {
        public bool EnableOCarousel { get; set; }
    }
}
