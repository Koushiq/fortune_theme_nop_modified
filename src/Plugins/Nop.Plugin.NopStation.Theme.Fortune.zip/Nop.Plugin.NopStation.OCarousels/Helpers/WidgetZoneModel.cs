﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.OCarousels.Helpers
{
    public class WidgetZoneModel
    {
        public string Name { get; set; }

        public int Value { get; set; }
    }
}
