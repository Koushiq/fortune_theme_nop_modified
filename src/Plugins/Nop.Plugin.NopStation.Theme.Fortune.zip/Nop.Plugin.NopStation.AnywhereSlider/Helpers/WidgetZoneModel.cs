﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.AnywhereSlider.Helpers
{
    public class WidgetZoneModel
    {
        public string Name { get; set; }

        public int Value { get; set; }
    }
}
