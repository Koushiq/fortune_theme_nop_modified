﻿using Nop.Core.Configuration;

namespace Nop.Plugin.NopStation.AnywhereSlider
{
    public class AnywhereSliderSettings : ISettings
    {
        public bool EnableSlider { get; set; }
    }
}