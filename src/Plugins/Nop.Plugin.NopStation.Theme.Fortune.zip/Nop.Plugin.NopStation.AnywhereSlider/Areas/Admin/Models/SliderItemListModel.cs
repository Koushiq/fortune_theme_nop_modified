﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.NopStation.AnywhereSlider.Areas.Admin.Models
{
    public class SliderItemListModel : BasePagedListModel<SliderItemModel>
    {
    }
}
