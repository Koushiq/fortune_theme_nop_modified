﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.NopStation.AnywhereSlider.Areas.Admin.Models
{
    public class SliderItemSearchModel : BaseSearchModel
    {
        public int SliderId { get; set; }
    }
}
