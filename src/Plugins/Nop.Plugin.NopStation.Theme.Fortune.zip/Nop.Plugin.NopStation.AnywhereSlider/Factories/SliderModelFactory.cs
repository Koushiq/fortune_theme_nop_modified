﻿using System;
using System.Collections.Generic;
using Nop.Core;
using Nop.Plugin.NopStation.AnywhereSlider.Services;
using Nop.Plugin.NopStation.AnywhereSlider.Domains;
using Nop.Plugin.NopStation.AnywhereSlider.Models;
using Nop.Services.Localization;
using Nop.Services.Media;
using Nop.Plugin.NopStation.Core.Services;

namespace Nop.Plugin.NopStation.AnywhereSlider.Factories
{
    public class SliderModelFactory : ISliderModelFactory
    {
        private readonly IPictureService _pictureService;
        private readonly ISliderService _sliderService;
        private readonly ILocalizationService _localizationService;
        private readonly IWorkContext _workContext;
        private readonly INopStationContext _nopStationContext;

        public SliderModelFactory(IPictureService pictureService,
            ISliderService sliderService,
            ILocalizationService localizationService,
            IWorkContext workContext,
            INopStationContext nopStationContext)
        {
            _pictureService = pictureService;
            _sliderService = sliderService;
            _localizationService = localizationService;
            _workContext = workContext;
            _nopStationContext = nopStationContext;
        }

        public IList<SliderModel> PrepareSliderListModel(List<Slider> sliders)
        {
            if (sliders == null)
                throw new ArgumentNullException(nameof(sliders));

            var mobileDevice = _nopStationContext.MobileDevice;
            var model = new List<SliderModel>();
            foreach (var slider in sliders)
            {
                model.Add(PrepareSliderModel(slider, mobileDevice));
            }
            return model;
        }

        public SliderModel PrepareSliderModel(Slider slider, bool mobileDevice) 
        {
            var sliderModel = new SliderModel()
            {
                Id = slider.Id,
                Name = slider.Name,
                WidgetZoneId = slider.WidgetZoneId,
                Nav = slider.Nav,
                AutoPlayHoverPause = slider.AutoPlayHoverPause,
                StartPosition = slider.StartPosition,
                LazyLoad = slider.LazyLoad,
                LazyLoadEager = slider.LazyLoadEager,
                Video = slider.Video,
                AnimateOut = slider.AnimateOut,
                AnimateIn = slider.AnimateIn,
                Loop = slider.Loop,
                AutoPlay = slider.AutoPlay,
                AutoPlayTimeout = slider.AutoPlayTimeout,
                RTL = _workContext.WorkingLanguage.Rtl
            };

            if (slider.ShowBackgroundPicture)
            {
                sliderModel.ShowBackgroundPicture = true;
                sliderModel.BackgroundPictureUrl = _pictureService.GetPictureUrl(slider.BackgroundPictureId);
            }

            var sliderItems = _sliderService.GetSliderItemsBySliderId(slider.Id);
            foreach (var si in sliderItems)
            {
                sliderModel.Items.Add(new SliderModel.SliderItemModel()
                {
                    Id = si.Id,
                    Title = _localizationService.GetLocalized(si, x => x.Title),
                    Link = _localizationService.GetLocalized(si, x => x.Link),
                    PictureUrl = _pictureService.GetPictureUrl(mobileDevice ? si.MobilePictureId : si.PictureId),
                    ImageAltText = _localizationService.GetLocalized(si, x => x.ImageAltText),
                    ShortDescription = _localizationService.GetLocalized(si, x => x.ShortDescription)
                });
            }

            return sliderModel;
        }
    }
}
